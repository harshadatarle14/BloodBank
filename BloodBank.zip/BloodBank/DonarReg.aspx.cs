﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class DonarReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                Bindddl();
            }
        }
        private void Bindddl()
        {
            string strselct = "select id,name from AreaMaster order by name";
            DatabaseFunction objcls = new DatabaseFunction();

            DataTable dt = objcls.GetData(strselct);
            ddl.DataSource = dt;
            ddl.DataValueField = "id";
            ddl.DataTextField = "name";
            ddl.DataBind();
        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {
            DatabaseFunction objcls = new DatabaseFunction();
            string gender = "";
            string Filepath = "";
            if (RBFemale.Checked == true)
                gender = "Female";
            else
                gender = "Male";

            DateTime currentDate = DateTime.Now;
            string filenm = currentDate.Ticks + txtname.Text.Split(' ')[0].Trim();
            if (FUReport.HasFile)
            {
                string fnm = FUReport.FileName;
                string[] str = fnm.Split('.');
                fnm = filenm + "." + str[1];
                FUReport.SaveAs(Server.MapPath("/MedicalReports/") + fnm);
                Filepath = Server.MapPath("/MedicalReports/") + fnm;
            }


            string strinsert = "Insert INTO [dbo].[Donar] (Name,username,phonenumber,password,Areaid,Email,Address,weight,Age,BloodGroup,MedicalReport,Gender) VALUES('" + txtname.Text + "','" + txtuser.Text + "','" + txtph.Text + "','" + txtpassword.Text + "'," + ddl.SelectedValue + ",'" + txtemail.Text + "','" + txtAddress.Text + "','" + txtweight.Text + "','" + txtAge.Text + "','" + ddlBG.SelectedValue + "','" + Filepath + "','" + gender + "')";
            string result = objcls.InsertUpdateDeleteData(strinsert);
            if (Convert.ToInt32(result) > 0)
            {
                lblmsg.Text = "Inserted!!";
                lblmsg.CssClass = "label-success";
            }
            else
            {
                lblmsg.Text = "Not Insert";
                lblmsg.CssClass = "label-danger";
            }
        }


    }
}