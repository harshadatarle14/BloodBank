﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class RecLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnlogin_Click(object sender, EventArgs e)
        {
            DatabaseFunction objdt = new DatabaseFunction();
            string strselect;
            strselect = "select * from Receiver where username='" + txtlogin.Text + "' and password='" + txtpassword.Text + "'";

            DataTable dt = objdt.GetData(strselect);

            if (dt.Rows.Count > 0)
            {
                //login successfull
                Session["Receiverdetail"] = dt;
                Response.Redirect("ReceiverDefault.aspx");



            }
            else
            {
                //login fail
                lblmsg.Text = "Enter Username and Password does not match.";
                lblmsg.CssClass = "label-danger";
            }

        }
    }
}