﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class Rec_ViewDoctorList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                Bindddl();
            }

        }
        private void Bindddl()
        {
            string strselct = "select id,name from AreaMaster order by name";
            DatabaseFunction objcls = new DatabaseFunction();

            DataTable dt = objcls.GetData(strselct);
            ddlarea.DataSource = dt;
            ddlarea.DataValueField = "id";
            ddlarea.DataTextField = "name";
            ddlarea.DataBind();

        }


        protected void btnsearch_Click(object sender, EventArgs e)
        {
            DatabaseFunction objcls = new DatabaseFunction();
            if (ddlBG.SelectedValue != "Select Blood Group")
            {
                string strselct = "select a.date,d.Name DonarName, dc.Name DocName, dc.Phonenumber dcPh from Appointment a inner join Donar d on a.DonarID=d.DonarID inner join Doctor dc on a.DoctorID=dc.Id where a.AreaID=" + ddlarea.SelectedValue + " and d.BloodGroup='" + ddlBG.SelectedValue + "' and a.Status='Y'";
                DataTable dt = objcls.GetData(strselct);

                if (dt.Rows.Count > 0)
                {
                    grd.DataSource = dt;
                    grd.DataBind();
                }
            }


        }

        protected void lnkstatus_Click(object sender, EventArgs e)
        {

        }
    }
}