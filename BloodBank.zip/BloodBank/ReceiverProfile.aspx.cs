﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class ReceiverProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                Bindddl();
            }
        }
        private void Bindddl()
        {
            string strselct = "select id,name from AreaMaster order by name";
            DatabaseFunction objcls = new DatabaseFunction();

            DataTable dt = objcls.GetData(strselct);
            ddl.DataSource = dt;
            ddl.DataValueField = "id";
            ddl.DataTextField = "name";
            ddl.DataBind();
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            DatabaseFunction objcls = new DatabaseFunction();
            string gender = "";

            if (RBFemale.Checked == true)
                gender = "Female";
            else
                gender = "Male";

            string strinsert = "Insert INTO [dbo].[Receiver] (Name,phonenumber,username,password,Address,Areaid,Email,BloodGroup,Gender) VALUES('" + txtph.Text + "','" + txtuser.Text + "','" + txtpassword.Text + "','" + txtAddress.Text + "'," + ddl.SelectedValue + ",'" + txtemail.Text + "','" + ddlBG.SelectedValue + "','" + gender + "')";
            string result = objcls.InsertUpdateDeleteData(strinsert);
            if (Convert.ToInt32(result) > 0)
            {
                lblmsg.Text = "Inserted!!";
                lblmsg.CssClass = "label-success";
            }
            else
            {
                lblmsg.Text = "Not Insert";
                lblmsg.CssClass = "label-danger";
            }

        }
        protected void btnupdatepassword_Click(object sender, EventArgs e)
        {

        }
    }
}