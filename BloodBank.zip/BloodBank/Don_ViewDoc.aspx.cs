﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class Don_ViewDoc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                Bindddl();
            }
        }
        private void Bindddl()
        {
            string strselct = "select id,name from AreaMaster order by name";
            DatabaseFunction objcls = new DatabaseFunction();

            DataTable dt = objcls.GetData(strselct);
            ddlarea.DataSource = dt;
            ddlarea.DataValueField = "id";
            ddlarea.DataTextField = "name";
            ddlarea.DataBind();
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            DatabaseFunction objcls = new DatabaseFunction();
            string strselect = "select d.Name,d.Email,d.Phonenumber,a.Name AreaName FROM Doctor d inner join AreaMaster a on d.AreaID=a.ID where d.Areaid=" + ddlarea.SelectedValue;
            DataTable dt = objcls.GetData(strselect);

            if (dt.Rows.Count > 0)
            {
                grd.DataSource = dt;
                grd.DataBind();
            }
        }
    }
}