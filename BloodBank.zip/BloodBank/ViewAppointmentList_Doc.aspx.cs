﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class ViewAppointmentList_Doc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dtdoctor = (DataTable)Session["Docdetail"];
            string ID = dtdoctor.Rows[0]["ID"].ToString();
            string str = "SELECT AppointmentID,Date,Status ,Donar.Name DonarName,Donar.BloodGroup From Appointment inner join  Donar on  Appointment.DonarID= Donar.DonarID  where DoctorID=" + ID;
            DatabaseFunction objdf = new DatabaseFunction();
            DataTable dtdn = objdf.GetData(str);
            if (dtdn.Rows.Count > 0)
            {
                grd.DataSource = dtdn;
                grd.DataBind();
            }
        }

        protected void grd_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            try
            {
                if (e.Item.ItemType == ListItemType.Item)
                { 
                    LinkButton lnk = (LinkButton)e.Item.FindControl("lnkstatus");
                    Label lbl = (Label)e.Item.FindControl("lblstatus");
                    Label lblDate = (Label)e.Item.FindControl("lblDate");
                    DateTime appDate = Convert.ToDateTime( lblDate.Text);
                    DateTime CurrentDate = DateTime.Now.Date;
                    if(appDate<= CurrentDate)
                    {

                        if (lbl.Text == "N")
                        {
                            lnk.Visible = false;
                            lbl.Visible = true;
                            lbl.Text = "Rejected";
                        }

                    }
                    else
                    {


                        if (lbl.Text == "N")
                        {
                            lnk.Visible = true;
                            lbl.Visible = false;
                        }
                        else
                        {
                            lnk.Visible = false;
                            lbl.Visible = true;
                            lbl.Text = "Accepted";
                        }
                    }

                   
               }
            }
            catch (Exception )
            {
                
            }
        }

        protected void lnkstatus_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            DataGridItem grdItem = (DataGridItem)lnk.NamingContainer;
            Label lbl = (Label)grdItem.FindControl("lblstatus");
            string appid = lnk.CommandArgument;
            if (lbl.Text == "N")
            {
                string strcommand = "update Appointment set status='Y' where AppointmentID=" + appid;
                DatabaseFunction objdf = new DatabaseFunction();
                string result = objdf.InsertUpdateDeleteData(strcommand);
                if (Convert.ToInt32(result) > 0)
                {
                   //BindGrid();
                    ScriptManager.RegisterStartupScript(this, GetType(), "displayalertmessage", "Showalert();", true);
                    BindGrid();
                }
            }
        }
    }
}