﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace BloodBank
{
    public class DatabaseFunction
    {
        string connectionstring = "Data Source=DESKTOP-MHB5TV2;Initial Catalog=DBBlood;Integrated Security=True";  
        public string InsertUpdateDeleteData(string strinsert)
        {
            string result = "";
            try
            {
                SqlConnection sqlcon = new SqlConnection();
                sqlcon.ConnectionString = connectionstring;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = strinsert;
                cmd.Connection = sqlcon;
                sqlcon.Open();
                int i = cmd.ExecuteNonQuery();
                sqlcon.Close();
                result = i.ToString();
               
            }
            catch (Exception ex)
            {
                result = ex.ToString();                
            }
            return result;
        }

        internal DataTable GetData(object strselect)
        {
            throw new NotImplementedException();
        }

        public DataTable GetData(string strselect)
        {
            DataTable dt = new DataTable();
            SqlConnection sqlcon = new SqlConnection();
            
            sqlcon.ConnectionString = connectionstring;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = strselect;
            cmd.Connection = sqlcon;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            return dt;
        }
    }
    

}

