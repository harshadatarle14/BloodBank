﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class Doc_ViewDonList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }
        private void BindGrid()
        {
            DataTable dt = (DataTable)Session["DocDetail"];
            string AreaID = dt.Rows[0]["AreaID"].ToString();
            string str = "SELECT [DonarID],d.[Name],[Address],[Phonenumber] ,[Email],[Weight],[Age],[Gender],[BloodGroup],[MedicalReport] FROM [dbo].[Donar]  d inner join AreaMaster a on d.[AreaID]=a.ID   where d.AreaID="+AreaID;
            DatabaseFunction objdf = new DatabaseFunction();
            DataTable dtd = objdf.GetData(str);
            if (dtd.Rows.Count > 0)
            {
                grd.DataSource = dtd;
                grd.DataBind();
            }

        }
        
    }
}