﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BloodBank
{
    public partial class AppointmentStatus_Don : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }

        }
        private void BindGrid()
        {
            DataTable dt = (DataTable)Session["Donardetail"];
            string AreaID = dt.Rows[0]["AreaID"].ToString();
            string DID = dt.Rows[0]["DonarID"].ToString();
            string str = "SELECT d.AppointmentID,d.Date,d.Status,dr.Name FROM [dbo].[Appointment]  d inner join AreaMaster a on d.[AreaID]=a.ID  inner join Doctor dr on d.[DoctorID]=dr.Id  where d.DonarID="+DID  ;
            DatabaseFunction objdf = new DatabaseFunction();
            DataTable dtdn = objdf.GetData(str);
            if (dt.Rows.Count > 0)
            {
                grd.DataSource = dtdn;
                grd.DataBind();
            }

        }

        protected void grd_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            
                if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
                {
                    
                    Label lbl = (Label)e.Item.FindControl("lblstatus");
                    if (lbl.Text == "N")
                        lbl.Text = "Rejected";
                    else
                        lbl.Text = "Accepted";
                }
           
         }
        //protected void lnkstatus_Click(object sender, EventArgs e)
        
        //{

        //    LinkButton lnk = (LinkButton)sender;
        //    DataGridItem grdItem = (DataGridItem)lnk.NamingContainer;
        //    Label lbl = (Label)grdItem.FindControl("lblstatus");
        //    string appid = lnk.CommandArgument;
        //}
    }
}
